package com.example.akosombotour;

import android.content.Context;

import java.util.ArrayList;

public class ToursitesModel {
    private String history;

    public ToursitesModel(String history) {
        this.history = history;
    }

    public String getHistory() {
        return history;
    }

    public static ArrayList<ToursitesModel> getUsers(Context context) {
        ArrayList<ToursitesModel> history = new ArrayList<ToursitesModel>();
        history.add(new ToursitesModel(context.getString(R.string.toursites)));
        history.add(new ToursitesModel(context.getString(R.string.toursites1)));
        history.add(new ToursitesModel(context.getString(R.string.toursites2)));
        history.add(new ToursitesModel(context.getString(R.string.toursites3)));
        return history;
    }
}


