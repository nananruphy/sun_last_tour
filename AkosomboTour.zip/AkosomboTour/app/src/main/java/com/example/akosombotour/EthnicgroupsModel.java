package com.example.akosombotour;

import android.content.Context;

import java.util.ArrayList;

public class EthnicgroupsModel {
    private String history;
    public EthnicgroupsModel(String history) {
        this.history = history;
    }
    public String getHistory(){
        return history;
    }
    public static ArrayList<EthnicgroupsModel> getUsers(Context context) {
        ArrayList<EthnicgroupsModel> history = new ArrayList<EthnicgroupsModel>();
        history.add(new EthnicgroupsModel(context.getString(R.string.ethnics)));
        history.add(new EthnicgroupsModel(context.getString(R.string.ethnics1)));
        history.add(new EthnicgroupsModel(context.getString(R.string.ethnics1)));
        history.add(new EthnicgroupsModel(context.getString(R.string.ethnics2)));
        history.add(new EthnicgroupsModel(context.getString(R.string.ethnics3)));
        history.add(new EthnicgroupsModel(context.getString(R.string.ethnics4)));
        history.add(new EthnicgroupsModel(context.getString(R.string.ethnics5)));
        history.add(new EthnicgroupsModel(context.getString(R.string.ethnics6)));
        return history;
    }
}
